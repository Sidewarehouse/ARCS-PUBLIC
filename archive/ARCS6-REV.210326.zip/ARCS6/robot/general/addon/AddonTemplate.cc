//! @file AddonTemplate.cc
//! @brief クラステンプレート
//!
//! クラス(テンプレート版)を追加する場合は，このクラステンプレートを基に作ってネ。
//!
//! @date 20XX/XX/XX
//! @author Yokokura, Yuki
//
// Copyright (C) 2011-20XX Yokokura, Yuki
// This program is free software;
// you can redistribute it and/or modify it under the terms of the FreeBSD License.
// For details, see the License.txt file.

#include "AddonTemplate.hh"

// テンプレートクラスのため，実体もヘッダ側に実装。

