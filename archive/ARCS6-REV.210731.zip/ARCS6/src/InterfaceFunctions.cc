//! @file InterfaceFunctions.cc
//! @brief インターフェースクラス
//! @date 2020/03/13
//! @author Yokokura, Yuki
//
// Copyright (C) 2011-2020 Yokokura, Yuki
// This program is free software;
// you can redistribute it and/or modify it under the terms of the BSD License.
// For details, see the License.txt file.

#include "InterfaceFunctions.hh"

// コーディング簡易化のために定義はヘッダに記述。

